const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const { createCanvas } = require('canvas');
const { v4: uuidv4 } = require('uuid');
const path = require('path');

const app = express();
const port = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public'));

// Store generated logos (in-memory storage for demo)
const generatedLogos = new Map();

// Generate logo function
async function generateLogo(settings) {
  const { companyName, slogan, selectedFonts, selectedColors } = settings;
  
  // Create canvas
  const canvas = createCanvas(500, 500);
  const ctx = canvas.getContext('2d');
  
  // Set background
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, 500, 500);
  
  // Configure text settings
  const primaryFont = selectedFonts[0] || 'Arial';
  const primaryColor = selectedColors[0] || '#000000';
  
  // Draw company name
  ctx.font = `bold 48px ${primaryFont}`;
  ctx.fillStyle = primaryColor;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(companyName, 250, 200);
  
  // Draw slogan if provided
  if (slogan) {
    const sloganFont = selectedFonts[1] || primaryFont;
    const sloganColor = selectedColors[1] || primaryColor;
    ctx.font = `24px ${sloganFont}`;
    ctx.fillStyle = sloganColor;
    ctx.fillText(slogan, 250, 300);
  }
  
  return canvas.toBuffer();
}

// API Routes
app.post('/api/generate-logo', async (req, res) => {
  try {
    const settings = req.body;
    
    // Validate required fields
    if (!settings.companyName) {
      return res.status(400).json({ error: 'Company name is required' });
    }
    
    if (!settings.selectedFonts?.length) {
      return res.status(400).json({ error: 'At least one font must be selected' });
    }
    
    if (!settings.selectedColors?.length) {
      return res.status(400).json({ error: 'At least one color must be selected' });
    }
    
    // Generate logo
    const logoBuffer = await generateLogo(settings);
    
    // Generate unique ID for the logo
    const logoId = uuidv4();
    
    // Store logo data
    generatedLogos.set(logoId, {
      buffer: logoBuffer,
      settings,
      createdAt: new Date()
    });
    
    // Return logo ID
    res.json({ 
      id: logoId,
      message: 'Logo generated successfully',
      previewUrl: `/api/logos/${logoId}`
    });
  } catch (error) {
    console.error('Error generating logo:', error);
    res.status(500).json({ error: 'Failed to generate logo' });
  }
});

// Get generated logo by ID
app.get('/api/logos/:id', (req, res) => {
  const { id } = req.params;
  const logo = generatedLogos.get(id);
  
  if (!logo) {
    return res.status(404).json({ error: 'Logo not found' });
  }
  
  res.set('Content-Type', 'image/png');
  res.send(logo.buffer);
});

// Start server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});