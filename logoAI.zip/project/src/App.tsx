import React, { useState } from 'react';
import { Settings, Palette, Type, Grid3X3, BookOpen, Github } from 'lucide-react';

interface LogoSettings {
  companyName: string;
  slogan: string;
  industry: string;
  selectedFonts: string[];
  selectedColors: string[];
  selectedDesigns: string[];
}

const FONTS = ['Arial', 'Helvetica', 'Roboto', 'Playfair Display', 'Montserrat', 'Open Sans'];
const COLORS = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEEAD', '#D4A5A5'];
const DESIGNS = ['Minimal', 'Modern', 'Vintage', 'Bold', 'Elegant', 'Playful'];
const INDUSTRIES = ['Technology', 'Fashion', 'Food & Beverage', 'Healthcare', 'Education', 'Entertainment'];

function App() {
  const [settings, setSettings] = useState<LogoSettings>({
    companyName: '',
    slogan: '',
    industry: '',
    selectedFonts: [],
    selectedColors: [],
    selectedDesigns: [],
  });

  const handleMultiSelect = (field: keyof LogoSettings, value: string) => {
    setSettings(prev => ({
      ...prev,
      [field]: prev[field].includes(value)
        ? prev[field].filter(item => item !== value)
        : [...prev[field], value]
    }));
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navbar */}
      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center">
              <Settings className="h-8 w-8 text-indigo-600" />
              <span className="ml-2 text-xl font-bold text-gray-900">LogoForge</span>
            </div>
            <div className="flex items-center space-x-4">
              <a href="#" className="text-gray-600 hover:text-gray-900">
                <Github className="h-6 w-6" />
              </a>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Left Side - Settings Panel */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-2xl font-bold mb-6">Logo Settings</h2>
            
            {/* Company Details */}
            <div className="space-y-4 mb-8">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Company Name
                </label>
                <input
                  type="text"
                  value={settings.companyName}
                  onChange={(e) => setSettings({...settings, companyName: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="Enter company name"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Slogan (Optional)
                </label>
                <input
                  type="text"
                  value={settings.slogan}
                  onChange={(e) => setSettings({...settings, slogan: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="Enter company slogan"
                />
              </div>
            </div>

            {/* Industry Selection */}
            <div className="mb-8">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Industry
              </label>
              <select
                value={settings.industry}
                onChange={(e) => setSettings({...settings, industry: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
              >
                <option value="">Select an industry</option>
                {INDUSTRIES.map(industry => (
                  <option key={industry} value={industry}>{industry}</option>
                ))}
              </select>
            </div>

            {/* Font Selection */}
            <div className="mb-8">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Fonts
              </label>
              <div className="grid grid-cols-2 gap-2">
                {FONTS.map(font => (
                  <button
                    key={font}
                    onClick={() => handleMultiSelect('selectedFonts', font)}
                    className={`px-4 py-2 rounded-md text-sm ${
                      settings.selectedFonts.includes(font)
                        ? 'bg-indigo-600 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {font}
                  </button>
                ))}
              </div>
            </div>

            {/* Color Selection */}
            <div className="mb-8">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Colors
              </label>
              <div className="grid grid-cols-6 gap-2">
                {COLORS.map(color => (
                  <button
                    key={color}
                    onClick={() => handleMultiSelect('selectedColors', color)}
                    className={`w-8 h-8 rounded-full border-2 ${
                      settings.selectedColors.includes(color)
                        ? 'border-indigo-600'
                        : 'border-transparent'
                    }`}
                    style={{ backgroundColor: color }}
                  />
                ))}
              </div>
            </div>

            {/* Design Style Selection */}
            <div className="mb-8">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Design Styles
              </label>
              <div className="grid grid-cols-2 gap-2">
                {DESIGNS.map(design => (
                  <button
                    key={design}
                    onClick={() => handleMultiSelect('selectedDesigns', design)}
                    className={`px-4 py-2 rounded-md text-sm ${
                      settings.selectedDesigns.includes(design)
                        ? 'bg-indigo-600 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {design}
                  </button>
                ))}
              </div>
            </div>

            <button className="w-full bg-indigo-600 text-white py-3 rounded-md hover:bg-indigo-700 transition-colors">
              Generate Logo
            </button>
          </div>

          {/* Right Side - Preview Area */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-2xl font-bold mb-6">Logo Preview</h2>
            <div className="aspect-square bg-gray-100 rounded-lg flex items-center justify-center">
              {settings.companyName ? (
                <div className="text-center">
                  <h1 className="text-4xl font-bold text-gray-900">{settings.companyName}</h1>
                  {settings.slogan && (
                    <p className="text-gray-600 mt-2">{settings.slogan}</p>
                  )}
                </div>
              ) : (
                <p className="text-gray-400">Enter company details to preview logo</p>
              )}
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <Settings className="h-6 w-6 text-indigo-600" />
              <span className="ml-2 text-lg font-semibold text-gray-900">LogoForge</span>
            </div>
            <div className="text-gray-500 text-sm">
              © 2024 LogoForge. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;