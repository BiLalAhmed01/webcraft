document.addEventListener('DOMContentLoaded', () => {
    // Language switching
    const languageSelect = document.getElementById('languageSelect');
    
    function updateLanguage(lang) {
        document.querySelectorAll('[data-lang-key]').forEach(element => {
            const key = element.getAttribute('data-lang-key');
            if (element.tagName === 'INPUT' && element.type === 'text') {
                element.placeholder = translations[lang][key];
            } else {
                element.textContent = translations[lang][key];
            }
        });
    }

    languageSelect.addEventListener('change', (e) => {
        updateLanguage(e.target.value);
    });

    // Initial language setup
    updateLanguage('en');

    // Create slides button
    const createButton = document.getElementById('createButton');
    const subscriptionModal = document.getElementById('subscriptionModal');
    
    createButton.addEventListener('click', () => {
        const prompt = document.getElementById('promptInput').value;
        if (prompt.trim() === '') {
            alert('Please enter a prompt for your presentation');
            return;
        }
        
        // Simulate presentation generation
        setTimeout(() => {
            subscriptionModal.style.display = 'block';
        }, 1500);
    });

    // Close modal when clicking outside
    subscriptionModal.addEventListener('click', (e) => {
        if (e.target === subscriptionModal) {
            subscriptionModal.style.display = 'none';
        }
    });

    // Subscription buttons
    document.querySelectorAll('.pricing-card button').forEach(button => {
        button.addEventListener('click', () => {
            const plan = button.getAttribute('data-plan');
            // Here you would integrate with a payment processor
            alert(`Processing ${plan} subscription...`);
        });
    });

    // Theme selection
    const themeInputs = document.querySelectorAll('input[name="theme"]');
    themeInputs.forEach(input => {
        input.addEventListener('change', (e) => {
            document.body.className = `theme-${e.target.value}`;
        });
    });

    // Custom theme upload
    const themeUpload = document.querySelector('.theme-upload input');
    themeUpload.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            // Here you would handle the custom theme file
            alert('Custom theme uploaded!');
        }
    });
});