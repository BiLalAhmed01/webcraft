import express from 'express';
import cors from 'cors';
import { rateLimit } from 'express-rate-limit';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const port = process.env.PORT || 3000;

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100 // limit each IP to 100 requests per windowMs
});

app.use(cors());
app.use(express.json());
app.use(limiter);
app.use(express.static('public'));

// Store users and subscriptions (in a real app, use a database)
const users = new Map();
const subscriptions = new Map();

// Auth Routes
app.post('/api/auth/register', async (req, res) => {
  try {
    const { name, email, password } = req.body;
    
    if (!name || !email || !password) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    if (users.has(email)) {
      return res.status(400).json({ error: 'Email already registered' });
    }

    // In a real app, hash the password before storing
    users.set(email, { name, password, createdAt: new Date() });
    
    res.json({ message: 'Registration successful' });
  } catch (error) {
    console.error('Error registering user:', error);
    res.status(500).json({ error: 'Failed to register user' });
  }
});

app.post('/api/auth/signin', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }

    const user = users.get(email);
    
    if (!user || user.password !== password) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // In a real app, generate and return a JWT token
    res.json({
      message: 'Sign in successful',
      user: {
        name: user.name,
        email
      }
    });
  } catch (error) {
    console.error('Error signing in:', error);
    res.status(500).json({ error: 'Failed to sign in' });
  }
});

// Presentations Route
app.post('/api/presentations/generate', async (req, res) => {
  try {
    const { prompt, theme } = req.body;
    
    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    // Simulate presentation generation
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // In a real app, you would generate the presentation here
    const presentationId = Date.now().toString();
    
    res.json({
      id: presentationId,
      message: 'Presentation generated successfully',
      requiresSubscription: true
    });
  } catch (error) {
    console.error('Error generating presentation:', error);
    res.status(500).json({ error: 'Failed to generate presentation' });
  }
});

// Subscriptions Route
app.post('/api/subscriptions', async (req, res) => {
  try {
    const { plan, paymentToken } = req.body;
    
    if (!plan || !paymentToken) {
      return res.status(400).json({ error: 'Plan and payment token are required' });
    }

    // Simulate payment processing
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Store subscription
    const subscriptionId = Date.now().toString();
    subscriptions.set(subscriptionId, {
      plan,
      createdAt: new Date(),
      active: true
    });
    
    res.json({
      subscriptionId,
      message: 'Subscription created successfully'
    });
  } catch (error) {
    console.error('Error processing subscription:', error);
    res.status(500).json({ error: 'Failed to process subscription' });
  }
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});