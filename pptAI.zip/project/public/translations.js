const translations = {
    en: {
        "dashboard": "Dashboard",
        "products": "Products",
        "pricing": "Pricing",
        "contact": "Contact",
        "api": "API",
        "resources": "Resources",
        "signin": "Sign in",
        "create": "Create slides now",
        "main-title": "AI PowerPoint Maker",
        "placeholder": "I want a slide deck about...",
        "white-theme": "White Theme",
        "purple-theme": "Purple Theme",
        "upload-theme": "Upload Custom Theme",
        "create-slides": "Create Slides",
        "subscription-required": "Subscription Required",
        "subscription-message": "Please subscribe to download your presentation"
    },
    zh: {
        "dashboard": "仪表板",
        "products": "产品",
        "pricing": "定价",
        "contact": "联系我们",
        "api": "API",
        "resources": "资源",
        "signin": "登录",
        "create": "立即创建幻灯片",
        "main-title": "AI 幻灯片制作器",
        "placeholder": "我想要一个关于...",
        "white-theme": "白色主题",
        "purple-theme": "紫色主题",
        "upload-theme": "上传自定义主题",
        "create-slides": "创建幻灯片",
        "subscription-required": "需要订阅",
        "subscription-message": "请订阅以下载您的演示文稿"
    }
};