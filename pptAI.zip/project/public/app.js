document.addEventListener('DOMContentLoaded', () => {
    // API endpoints
    const API_URL = window.location.origin;
    const GENERATE_ENDPOINT = `${API_URL}/api/presentations/generate`;
    const SUBSCRIBE_ENDPOINT = `${API_URL}/api/subscriptions`;
    const AUTH_ENDPOINT = `${API_URL}/api/auth`;

    // Language switching
    const languageSelect = document.getElementById('languageSelect');
    
    function updateLanguage(lang) {
        document.querySelectorAll('[data-lang-key]').forEach(element => {
            const key = element.getAttribute('data-lang-key');
            if (element.tagName === 'INPUT' && element.type === 'text') {
                element.placeholder = translations[lang][key];
            } else {
                element.textContent = translations[lang][key];
            }
        });
    }

    languageSelect.addEventListener('change', (e) => {
        updateLanguage(e.target.value);
    });

    // Initial language setup
    updateLanguage('en');

    // Auth Modal
    const signinButton = document.getElementById('signinButton');
    const authModal = document.getElementById('authModal');
    const authTabs = document.querySelectorAll('.auth-tab');
    const signinForm = document.getElementById('signinForm');
    const registerForm = document.getElementById('registerForm');

    signinButton.addEventListener('click', () => {
        authModal.style.display = 'block';
    });

    // Close modal when clicking outside
    authModal.addEventListener('click', (e) => {
        if (e.target === authModal) {
            authModal.style.display = 'none';
        }
    });

    // Tab switching
    authTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const targetTab = tab.getAttribute('data-tab');
            
            // Update active tab
            authTabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            
            // Show corresponding form
            if (targetTab === 'signin') {
                signinForm.classList.remove('hidden');
                registerForm.classList.add('hidden');
            } else {
                signinForm.classList.add('hidden');
                registerForm.classList.remove('hidden');
            }
        });
    });

    // Google Auth
    document.querySelectorAll('.google-auth-btn').forEach(button => {
        button.addEventListener('click', async () => {
            try {
                // In a real app, you would implement Google OAuth here
                alert('Google authentication would be implemented here');
            } catch (error) {
                console.error('Error with Google auth:', error);
                alert('Failed to authenticate with Google');
            }
        });
    });

    // Sign In Form
    signinForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const email = document.getElementById('signinEmail').value;
        const password = document.getElementById('signinPassword').value;
        
        try {
            const response = await fetch(`${AUTH_ENDPOINT}/signin`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ email, password })
            });

            const data = await response.json();
            
            if (response.ok) {
                alert('Signed in successfully!');
                authModal.style.display = 'none';
                // Update UI for signed-in state
                signinButton.textContent = 'Sign out';
            } else {
                throw new Error(data.error);
            }
        } catch (error) {
            console.error('Error signing in:', error);
            alert('Failed to sign in. Please check your credentials.');
        }
    });

    // Register Form
    registerForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const name = document.getElementById('registerName').value;
        const email = document.getElementById('registerEmail').value;
        const password = document.getElementById('registerPassword').value;
        const confirmPassword = document.getElementById('confirmPassword').value;
        
        if (password !== confirmPassword) {
            alert('Passwords do not match');
            return;
        }
        
        try {
            const response = await fetch(`${AUTH_ENDPOINT}/register`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ name, email, password })
            });

            const data = await response.json();
            
            if (response.ok) {
                alert('Registered successfully! Please sign in.');
                // Switch to sign in tab
                authTabs[0].click();
            } else {
                throw new Error(data.error);
            }
        } catch (error) {
            console.error('Error registering:', error);
            alert('Failed to register. Please try again.');
        }
    });

    // Create slides button
    const createButton = document.getElementById('createButton');
    const subscriptionModal = document.getElementById('subscriptionModal');
    
    createButton.addEventListener('click', async () => {
        const prompt = document.getElementById('promptInput').value;
        if (prompt.trim() === '') {
            alert('Please enter a prompt for your presentation');
            return;
        }

        const theme = document.querySelector('input[name="theme"]:checked').value;
        createButton.disabled = true;
        createButton.textContent = 'Generating...';
        
        try {
            const response = await fetch(GENERATE_ENDPOINT, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ prompt, theme })
            });

            const data = await response.json();
            
            if (data.requiresSubscription) {
                subscriptionModal.style.display = 'block';
            }
        } catch (error) {
            console.error('Error generating presentation:', error);
            alert('Failed to generate presentation. Please try again.');
        } finally {
            createButton.disabled = false;
            createButton.textContent = 'Create Slides';
        }
    });

    // Close subscription modal when clicking outside
    subscriptionModal.addEventListener('click', (e) => {
        if (e.target === subscriptionModal) {
            subscriptionModal.style.display = 'none';
        }
    });

    // Subscription buttons
    document.querySelectorAll('.pricing-card button').forEach(button => {
        button.addEventListener('click', async () => {
            const plan = button.getAttribute('data-plan');
            button.disabled = true;
            button.textContent = 'Processing...';
            
            try {
                const paymentToken = 'dummy_token';
                
                const response = await fetch(SUBSCRIBE_ENDPOINT, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ plan, paymentToken })
                });

                const data = await response.json();
                
                if (response.ok) {
                    alert('Subscription successful! You can now download your presentation.');
                    subscriptionModal.style.display = 'none';
                } else {
                    throw new Error(data.error);
                }
            } catch (error) {
                console.error('Error processing subscription:', error);
                alert('Failed to process subscription. Please try again.');
            } finally {
                button.disabled = false;
                button.textContent = 'Subscribe';
            }
        });
    });

    // Theme selection
    const themeInputs = document.querySelectorAll('input[name="theme"]');
    themeInputs.forEach(input => {
        input.addEventListener('change', (e) => {
            document.body.className = `theme-${e.target.value}`;
        });
    });

    // Custom theme upload
    const themeUpload = document.querySelector('.theme-upload input');
    themeUpload.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            alert('Custom theme uploaded!');
        }
    });
});