# Project Management Platform

A collaborative project management solution for streamlined project planning, execution, and monitoring.

## Features

- Project planning and task management
- Real-time collaboration tools
- Resource allocation
- Performance analytics
- Team communication tools

## Tech Stack

- Backend: Django 4.x, Django REST Framework
- Frontend: React with Tailwind CSS
- Database: PostgreSQL
- Cache & Message Broker: Redis
- Real-time Features: Django Channels
- Background Tasks: Celery

## Prerequisites

- Python 3.9+
- PostgreSQL
- Redis
- Node.js 16+

## Setup Instructions

1. Clone the repository:
```bash
git clone <repository-url>
cd pms-platform
```

2. Create and activate virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: .\venv\Scripts\activate
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

4. Configure environment variables:
- Copy `.env.example` to `.env`
- Update the variables with your configuration

5. Setup database:
```bash
python manage.py migrate
```

6. Create superuser:
```bash
python manage.py createsuperuser
```

7. Start Redis server:
```bash
redis-server
```

8. Start Celery worker:
```bash
celery -A pms_backend worker -l info
```

9. Run development server:
```bash
python manage.py runserver
```

## Development

### Code Style
- Follow PEP 8 guidelines
- Use Black for code formatting
- Run isort for import sorting

### Testing
```bash
pytest
```

### API Documentation
API documentation is available at `/api/docs/` when running the development server.

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Contributing

1. Fork the repository
2. Create your feature branch
3. Commit your changes
4. Push to the branch
5. Create a new Pull Request 