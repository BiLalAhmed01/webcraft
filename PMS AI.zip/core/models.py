from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
from django.core.validators import MinValueValidator, MaxValueValidator
from django.core.exceptions import ValidationError
from decimal import Decimal
import json

class TeamMember(models.Model):
    ROLE_CHOICES = [
        ('developer', 'Developer'),
        ('designer', 'Designer'),
        ('manager', 'Project Manager'),
        ('analyst', 'Business Analyst'),
        ('tester', 'QA Tester'),
        ('other', 'Other')
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='team_memberships')
    project = models.ForeignKey('Project', on_delete=models.CASCADE, related_name='team_members')
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='developer')
    joined_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ('user', 'project')
    
    def __str__(self):
        return f"{self.user.get_full_name() or self.user.username} - {self.get_role_display()}"

class Project(models.Model):
    STATUS_CHOICES = [
        ('not_started', 'Not Started'),
        ('in_progress', 'In Progress'),
        ('completed', 'Completed'),
        ('on_hold', 'On Hold')
    ]
    
    name = models.CharField(max_length=200)
    description = models.TextField(default='')
    requirements = models.TextField(default='')
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='created_projects')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    start_date = models.DateField(default=timezone.now)
    deadline = models.DateField()
    budget = models.DecimalField(max_digits=12, decimal_places=2, validators=[MinValueValidator(0)], default=0)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='not_started')
    team_size = models.IntegerField(validators=[MinValueValidator(1)], default=1)
    members = models.ManyToManyField(User, through='TeamMember', related_name='member_projects')
    progress = models.IntegerField(default=0, validators=[MinValueValidator(0)])
    sprint_length = models.IntegerField(
        default=14,
        help_text="Sprint length in days"
    )
    story_points_per_sprint = models.IntegerField(default=0)
    
    @property
    def days_until_deadline(self):
        return (self.deadline - timezone.now().date()).days
    
    @property
    def is_overdue(self):
        return self.days_until_deadline < 0
    
    def __str__(self):
        return self.name

class ProjectMilestone(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('in_progress', 'In Progress'),
        ('completed', 'Completed'),
        ('delayed', 'Delayed')
    ]
    
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='milestones')
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    due_date = models.DateField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.project.name} - {self.title}"

class RequiredSkill(models.Model):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='required_skills')
    name = models.CharField(max_length=100)
    
    def __str__(self):
        return self.name

class ProjectUpdate(models.Model):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='updates')
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.project.name} - Update by {self.author.username}" 

class Task(models.Model):
    STATUS_CHOICES = [
        ('todo', 'To Do'),
        ('in_progress', 'In Progress'),
        ('blocked', 'Blocked'),
        ('completed', 'Completed')
    ]
    
    PRIORITY_CHOICES = [
        ('low', 'Low'),
        ('medium', 'Medium'),
        ('high', 'High'),
        ('urgent', 'Urgent')
    ]
    
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='tasks')
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    assigned_to = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='todo')
    priority = models.CharField(max_length=20, choices=PRIORITY_CHOICES, default='medium')
    due_date = models.DateField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    progress = models.IntegerField(
        default=0,
        validators=[MinValueValidator(0), MaxValueValidator(100)]
    )
    
    class Meta:
        ordering = ['-priority', 'due_date', 'created_at']
    
    def __str__(self):
        return self.title
    
    @property
    def is_overdue(self):
        return self.due_date < timezone.now().date() and self.status != 'completed'
    
    @property
    def is_blocked(self):
        return self.status == 'blocked'
    
    @property
    def completion_percentage(self):
        return self.progress
    
    @property
    def time_spent(self):
        return self.actual_hours
    
    @property
    def time_remaining(self):
        if self.status == 'completed':
            return 0
        return max(0, float(self.estimated_hours - self.actual_hours))
    
    @property
    def efficiency_ratio(self):
        if self.actual_hours == 0:
            return 0
        return float(self.estimated_hours / self.actual_hours)
    
    def clean(self):
        if self.due_date and self.due_date < timezone.now().date():
            raise ValidationError("Due date cannot be in the past")
        
        if self.status == 'completed' and self.progress != 100:
            self.progress = 100
        
        if self.status == 'not_started' and self.progress > 0:
            self.status = 'in_progress'
    
    def save(self, *args, **kwargs):
        # Auto-update status based on progress
        if self.progress == 100 and self.status != 'completed':
            self.status = 'completed'
        elif self.progress == 0 and self.status == 'completed':
            self.status = 'not_started'
        
        super().save(*args, **kwargs)

class Sprint(models.Model):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='sprints')
    name = models.CharField(max_length=100)
    start_date = models.DateField()
    end_date = models.DateField()
    goals = models.TextField()
    status = models.CharField(max_length=20, choices=[
        ('planned', 'Planned'),
        ('active', 'Active'),
        ('completed', 'Completed')
    ])
    velocity = models.DecimalField(max_digits=6, decimal_places=2, default=0)
    retrospective = models.TextField(blank=True)