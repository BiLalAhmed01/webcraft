from rest_framework import viewsets, permissions, status
from rest_framework.decorators import action
from rest_framework.response import Response
from django.shortcuts import get_object_or_404
from django.contrib.auth.models import User
from .models import Project, ProjectMember, Task, Comment, Document, AIRecommendation
from .serializers import (
    UserSerializer, ProjectSerializer, ProjectDetailSerializer,
    ProjectMemberSerializer, TaskSerializer, TaskDetailSerializer,
    CommentSerializer, DocumentSerializer, AIRecommendationSerializer
)
from .permissions import IsProjectMember, IsProjectAdmin
from django.http import JsonResponse
from django.views.decorators.http import require_http_methods

class UserViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [permissions.IsAuthenticated]

class ProjectViewSet(viewsets.ModelViewSet):
    serializer_class = ProjectSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return Project.objects.filter(team_members=self.request.user)

    def get_serializer_class(self):
        if self.action == 'retrieve':
            return ProjectDetailSerializer
        return ProjectSerializer

    def perform_create(self, serializer):
        project = serializer.save(owner=self.request.user)
        ProjectMember.objects.create(
            user=self.request.user,
            project=project,
            role=ProjectMember.Role.ADMIN
        )

    @action(detail=True, methods=['post'])
    def add_member(self, request, pk=None):
        project = self.get_object()
        user_id = request.data.get('user_id')
        role = request.data.get('role', ProjectMember.Role.TEAM_MEMBER)

        if not user_id:
            return Response(
                {'error': 'user_id is required'},
                status=status.HTTP_400_BAD_REQUEST
            )

        user = get_object_or_404(User, id=user_id)
        ProjectMember.objects.create(user=user, project=project, role=role)
        return Response(status=status.HTTP_201_CREATED)

class TaskViewSet(viewsets.ModelViewSet):
    serializer_class = TaskSerializer
    permission_classes = [permissions.IsAuthenticated, IsProjectMember]

    def get_queryset(self):
        return Task.objects.filter(project__team_members=self.request.user)

    def get_serializer_class(self):
        if self.action == 'retrieve':
            return TaskDetailSerializer
        return TaskSerializer

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

    @action(detail=True, methods=['post'])
    def assign(self, request, pk=None):
        task = self.get_object()
        user_id = request.data.get('user_id')

        if not user_id:
            return Response(
                {'error': 'user_id is required'},
                status=status.HTTP_400_BAD_REQUEST
            )

        user = get_object_or_404(User, id=user_id)
        if not task.project.team_members.filter(id=user.id).exists():
            return Response(
                {'error': 'User is not a member of the project'},
                status=status.HTTP_400_BAD_REQUEST
            )

        task.assignee = user
        task.save()
        return Response(TaskSerializer(task).data)

class CommentViewSet(viewsets.ModelViewSet):
    serializer_class = CommentSerializer
    permission_classes = [permissions.IsAuthenticated, IsProjectMember]

    def get_queryset(self):
        return Comment.objects.filter(task__project__team_members=self.request.user)

    def perform_create(self, serializer):
        serializer.save(author=self.request.user)

class DocumentViewSet(viewsets.ModelViewSet):
    serializer_class = DocumentSerializer
    permission_classes = [permissions.IsAuthenticated, IsProjectMember]

    def get_queryset(self):
        return Document.objects.filter(project__team_members=self.request.user)

    def perform_create(self, serializer):
        serializer.save(uploaded_by=self.request.user)

class AIRecommendationViewSet(viewsets.ModelViewSet):
    serializer_class = AIRecommendationSerializer
    permission_classes = [permissions.IsAuthenticated, IsProjectMember]

    def get_queryset(self):
        return AIRecommendation.objects.filter(project__team_members=self.request.user)

    @action(detail=True, methods=['post'])
    def implement(self, request, pk=None):
        recommendation = self.get_object()
        recommendation.is_implemented = True
        recommendation.save()
        return Response(AIRecommendationSerializer(recommendation).data) 

@require_http_methods(["POST"])
def delete_project(request, project_id):
    try:
        project = Project.objects.get(id=project_id)
        project_name = project.name
        project.delete()
        return JsonResponse({
            'success': True,
            'message': f'Project "{project_name}" was successfully deleted.'
        })
    except Project.DoesNotExist:
        return JsonResponse({
            'success': False,
            'error': 'Project not found'
        }, status=404)
    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': str(e)
        }, status=500) 