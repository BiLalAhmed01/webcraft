from django.urls import path
from .views import auth_views, project_views, dashboard_views, task_views, user_views

app_name = 'core'

urlpatterns = [
    # Landing Page (root URL)
    path('', auth_views.LandingView.as_view(), name='landing'),
    
    # Authentication URLs
    path('login/', auth_views.LoginView.as_view(), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('register/', auth_views.RegisterView.as_view(), name='register'),
    
    # Dashboard URLs
    path('dashboard/', dashboard_views.DashboardView.as_view(), name='dashboard'),
    
    # Project URLs
    path('projects/create/', project_views.ProjectCreateView.as_view(), name='project_create'),
    path('projects/<int:pk>/', project_views.ProjectDetailView.as_view(), name='project_detail'),
    path('projects/<int:pk>/edit/', project_views.ProjectUpdateView.as_view(), name='project_update'),
    path('projects/<int:pk>/delete/', project_views.ProjectDeleteView.as_view(), name='project_delete'),
    path('projects/<int:pk>/add-team-member/', project_views.add_team_member, name='add_team_member'),
    
    # Task URLs
    path('projects/<int:project_id>/tasks/', task_views.TaskListView.as_view(), name='task_list'),
    path('projects/<int:project_id>/tasks/create/', task_views.TaskCreateView.as_view(), name='task_create'),
    path('projects/<int:project_id>/tasks/<int:pk>/update/', task_views.TaskUpdateView.as_view(), name='task_update'),
    path('projects/<int:project_id>/tasks/<int:pk>/delete/', task_views.TaskDeleteView.as_view(), name='task_delete'),
    
    # User URLs
    path('profile/', user_views.ProfileView.as_view(), name='profile'),
] 