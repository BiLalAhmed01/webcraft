from django import forms
from django.utils import timezone
from .models import Project, Task
from django.contrib.auth.models import User

class ProjectForm(forms.ModelForm):
    class Meta:
        model = Project
        fields = ['name', 'description', 'requirements', 'budget', 'team_size', 'deadline']
        widgets = {
            'name': forms.TextInput(attrs={
                'class': 'block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white',
                'placeholder': 'Enter project name'
            }),
            'description': forms.Textarea(attrs={
                'class': 'block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white',
                'placeholder': 'Enter project description',
                'rows': '3'
            }),
            'requirements': forms.Textarea(attrs={
                'class': 'block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white',
                'placeholder': 'Enter project requirements',
                'rows': '4'
            }),
            'budget': forms.NumberInput(attrs={
                'class': 'block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white',
                'placeholder': 'Enter project budget',
                'min': '0',
                'step': '0.01'
            }),
            'team_size': forms.NumberInput(attrs={
                'class': 'block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white',
                'placeholder': 'Enter team size',
                'min': '1'
            }),
            'deadline': forms.DateInput(attrs={
                'class': 'block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white',
                'type': 'date'
            })
        }

    def clean_deadline(self):
        deadline = self.cleaned_data.get('deadline')
        if deadline and deadline < timezone.now().date():
            raise forms.ValidationError("Deadline cannot be in the past")
        return deadline

    def clean_budget(self):
        budget = self.cleaned_data.get('budget')
        if budget and budget <= 0:
            raise forms.ValidationError("Budget must be greater than zero")
        return budget

    def clean_team_size(self):
        team_size = self.cleaned_data.get('team_size')
        if team_size and team_size <= 0:
            raise forms.ValidationError("Team size must be greater than zero")
        return team_size 

class TaskForm(forms.ModelForm):
    class Meta:
        model = Task
        fields = [
            'title', 
            'description', 
            'assigned_to', 
            'status', 
            'priority', 
            'due_date'
        ]
        widgets = {
            'due_date': forms.DateInput(attrs={'type': 'date'}),
            'description': forms.Textarea(attrs={'rows': 3}),
        }

    def __init__(self, *args, project=None, **kwargs):
        super().__init__(*args, **kwargs)
        if project:
            # Filter assigned_to to only show team members using team_memberships
            self.fields['assigned_to'].queryset = User.objects.filter(
                team_memberships__project=project
            )