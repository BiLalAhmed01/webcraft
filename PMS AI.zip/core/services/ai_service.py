import google.generativeai as genai
from django.conf import settings
from typing import Dict, Any
import json
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class AIService:
    def __init__(self):
        try:
            genai.configure(api_key=settings.GEMINI_API_KEY)
            self.model = genai.GenerativeModel('gemini-pro')
            logger.info("AIService initialized successfully")
        except Exception as e:
            logger.error(f"Error initializing AIService: {str(e)}")
            raise
    
    def analyze_project(self, project_data: Dict[str, Any]) -> Dict[str, Any]:
        try:
            logger.info("Starting project analysis")
            
            # Create the prompt template
            prompt_template = """
            Analyze this project and provide insights:
            
            Project: {name}
            Description: {description}
            
            Tasks:
            {tasks}
            
            Team Members:
            {team}
            
            Please provide:
            1. Risk Assessment (3-4 key risks)
            2. Recommendations (3-4 actionable items)
            3. Resource Allocation suggestions
            
            Respond with a JSON object containing these exact keys:
            {{
                "risks": ["risk1", "risk2", "risk3"],
                "recommendations": ["rec1", "rec2", "rec3"],
                "resource_allocation": {{
                    "roles": [
                        {{"role": "role1", "allocation": "details"}},
                        {{"role": "role2", "allocation": "details"}}
                    ]
                }}
            }}
            """
            
            # Format the prompt with project data
            prompt = prompt_template.format(
                name=project_data['name'],
                description=project_data['description'],
                tasks=self._format_tasks(project_data['tasks']),
                team=self._format_team(project_data['team_members'])
            )
            
            logger.debug(f"Sending prompt to Gemini: {prompt}")
            response = self.model.generate_content(prompt)
            logger.debug(f"Received response from Gemini: {response.text}")
            
            # Clean the response text
            response_text = response.text.strip()
            if response_text.startswith('```'):
                response_text = response_text.split('\n', 1)[1]
            if response_text.endswith('```'):
                response_text = response_text.rsplit('\n', 1)[0]
            if response_text.startswith('json'):
                response_text = response_text.split('\n', 1)[1]
            
            # Parse the JSON
            try:
                analysis = json.loads(response_text)
                
                # Extract risks from objects if needed
                risks = [r['risk'] if isinstance(r, dict) else r for r in analysis.get('risks', [])]
                recommendations = [r['recommendation'] if isinstance(r, dict) else r for r in analysis.get('recommendations', [])]
                
                return {
                    'risks': risks,
                    'recommendations': recommendations,
                    'resource_allocation': analysis.get('resource_allocation', {})
                }
            except json.JSONDecodeError as e:
                logger.error(f"Error parsing AI response: {e}")
                return self._format_fallback_response(response_text)
                
        except Exception as e:
            logger.error(f"Error in AI analysis: {str(e)}", exc_info=True)
            return {
                'risks': ['Technical issues prevented complete analysis'],
                'recommendations': ['Retry analysis later'],
                'resource_allocation': {}
            }
    
    def _format_tasks(self, tasks):
        return "\n".join([f"- {task['title']}: {task['status']}" for task in tasks])
    
    def _format_team(self, team):
        return "\n".join([f"- {member['user__username']} ({member['role']})" for member in team])
    
    def _format_fallback_response(self, text):
        return {
            'risks': [text.split('\n')[0]],
            'recommendations': ['Review project details and try again'],
            'resource_allocation': {}
        }