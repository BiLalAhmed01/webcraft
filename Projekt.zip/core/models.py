from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
from django.core.validators import MinValueValidator, MaxValueValidator
from django.core.exceptions import ValidationError
from decimal import Decimal
import json

class TeamMember(models.Model):
    ROLE_CHOICES = [
        ('developer', 'Developer'),
        ('designer', 'Designer'),
        ('manager', 'Project Manager'),
        ('analyst', 'Business Analyst'),
        ('tester', 'QA Tester'),
        ('other', 'Other')
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='team_memberships')
    project = models.ForeignKey('Project', on_delete=models.CASCADE, related_name='team_members')
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='developer')
    joined_at = models.DateTimeField(auto_now_add=True)
    skills = models.ManyToManyField('RequiredSkill', blank=True)
    hourly_rate = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    
    class Meta:
        unique_together = ('user', 'project')
    
    def __str__(self):
        return f"{self.user.get_full_name() or self.user.username} - {self.get_role_display()}"

    def save(self, *args, **kwargs):
        # Check if there's already a manager for this project
        if self.role == 'manager' and not self.pk:  # Only check on creation
            existing_manager = TeamMember.objects.filter(
                project=self.project, 
                role='manager'
            ).exists()
            if existing_manager:
                raise ValidationError('This project already has a manager.')
        super().save(*args, **kwargs)

class Project(models.Model):
    STATUS_CHOICES = [
        ('not_started', 'Not Started'),
        ('in_progress', 'In Progress'),
        ('completed', 'Completed'),
        ('on_hold', 'On Hold')
    ]
    
    name = models.CharField(max_length=200)
    description = models.TextField(default='')
    requirements = models.TextField(default='')
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='created_projects')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    start_date = models.DateField(default=timezone.now)
    deadline = models.DateField()
    budget = models.DecimalField(max_digits=12, decimal_places=2, validators=[MinValueValidator(0)], default=0)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='not_started')
    team_size = models.IntegerField(validators=[MinValueValidator(1)], default=1)
    members = models.ManyToManyField(User, through='TeamMember', related_name='member_projects')
    progress = models.IntegerField(default=0, validators=[MinValueValidator(0)])
    
    # AI Analysis Fields
    _risk_assessment = models.JSONField(default=list, blank=True, db_column='risk_assessment')
    _ai_recommendations = models.JSONField(default=list, blank=True, db_column='ai_recommendations')
    _resource_allocation = models.JSONField(default=dict, blank=True, db_column='resource_allocation')
    _has_ai_analysis = models.BooleanField(default=False, db_column='has_ai_analysis')
    
    # Add new fields for AI-driven features
    sprint_length = models.IntegerField(default=14, help_text="Sprint length in days")
    story_points_per_sprint = models.IntegerField(default=0)
    velocity = models.DecimalField(max_digits=6, decimal_places=2, default=0)
    risk_level = models.CharField(
        max_length=20,
        choices=[('low', 'Low'), ('medium', 'Medium'), ('high', 'High')],
        default='medium'
    )
    
    ai_analysis = models.JSONField(null=True, blank=True)
    
    @property
    def days_until_deadline(self):
        return (self.deadline - timezone.now().date()).days
    
    @property
    def is_overdue(self):
        return self.days_until_deadline < 0
    
    @property
    def risk_assessment(self):
        if self.ai_analysis and 'risks' in self.ai_analysis:
            return self.ai_analysis['risks']
        return []
    
    @property
    def recommendations(self):
        if self.ai_analysis and 'recommendations' in self.ai_analysis:
            return self.ai_analysis['recommendations']
        return []
    
    @property
    def resource_allocation(self):
        if self.ai_analysis and 'resource_allocation' in self.ai_analysis:
            return self.ai_analysis['resource_allocation']
        return {'roles': []}
    
    @property
    def has_ai_analysis(self):
        return self._has_ai_analysis
    
    @has_ai_analysis.setter
    def has_ai_analysis(self, value):
        self._has_ai_analysis = value
    
    def update_ai_analysis(self, analysis_data):
        if not isinstance(analysis_data, dict):
            raise ValueError("Analysis data must be a dictionary")
        self.ai_analysis = analysis_data
        self.last_ai_update = timezone.now()
        self.save()
    
    @property
    def current_sprint_tasks(self):
        return self.tasks.filter(
            start_date__lte=timezone.now(),
            due_date__gte=timezone.now()
        ).order_by('priority', 'due_date')
    
    @property
    def blocked_tasks(self):
        return self.tasks.filter(status='blocked')
    
    @property
    def resource_utilization(self):
        team_utilization = {}
        for member in self.team_members.all():
            assigned_hours = sum(
                task.estimated_hours for task in member.assigned_tasks.all()
            )
            team_utilization[member.id] = {
                'name': str(member),
                'assigned_hours': float(assigned_hours),
                'available_hours': 40 * 4,  # Assuming 4 weeks per month
                'utilization_percentage': min(float(assigned_hours / (40 * 4) * 100), 100)
            }
        return team_utilization
    
    def __str__(self):
        return self.name

    def get_task_statistics(self):
        """Returns statistics about project tasks"""
        tasks = self.tasks.all()
        return {
            'total': tasks.count(),
            'completed': tasks.filter(status='completed').count(),
            'in_progress': tasks.filter(status='in_progress').count(),
            'blocked': tasks.filter(status='blocked').count(),
            'not_started': tasks.filter(status='not_started').count(),
        }

    def get_available_users(self):
        """Returns users that can be added to the project"""
        from django.contrib.auth.models import User
        current_members = self.members.all()
        return User.objects.exclude(id__in=current_members.values_list('id', flat=True))

    @property
    def team_member_roles(self):
        """Returns available team member roles"""
        return TeamMember.ROLE_CHOICES

    def set_risk_assessment(self, risks):
        self.risk_assessment = risks
        self.save()

    def set_ai_recommendations(self, recommendations):
        self.ai_recommendations = recommendations
        self.save()

    def set_resource_allocation(self, allocation):
        self.resource_allocation = allocation
        self.save()

    @property
    def tasks(self):
        return Task.objects.filter(project=self)

class ProjectMilestone(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('in_progress', 'In Progress'),
        ('completed', 'Completed'),
        ('delayed', 'Delayed')
    ]
    
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='milestones')
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    due_date = models.DateField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.project.name} - {self.title}"

class RequiredSkill(models.Model):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='required_skills')
    name = models.CharField(max_length=100)
    
    def __str__(self):
        return self.name

class ProjectUpdate(models.Model):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='updates')
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.project.name} - Update by {self.author.username}" 

class Task(models.Model):
    STATUS_CHOICES = (
        ('todo', 'To Do'),
        ('in_progress', 'In Progress'),
        ('completed', 'Completed'),
        ('blocked', 'Blocked'),
    )
    
    PRIORITY_CHOICES = (
        ('low', 'Low'),
        ('medium', 'Medium'),
        ('high', 'High'),
        ('urgent', 'Urgent')
    )
    
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='project_tasks')
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    assigned_to = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='todo')
    priority = models.CharField(max_length=20, choices=PRIORITY_CHOICES, default='medium')
    due_date = models.DateField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    progress = models.IntegerField(
        default=0,
        validators=[MinValueValidator(0), MaxValueValidator(100)]
    )
    
    class Meta:
        ordering = ['-priority', 'due_date', 'created_at']
    
    def __str__(self):
        return self.title
    
    @property
    def is_overdue(self):
        return self.due_date < timezone.now().date() and self.status != 'completed'
    
    @property
    def is_blocked(self):
        return self.status == 'blocked'
    
    @property
    def completion_percentage(self):
        return self.progress
    
    @property
    def time_spent(self):
        return self.actual_hours
    
    @property
    def time_remaining(self):
        if self.status == 'completed':
            return 0
        return max(0, float(self.estimated_hours - self.actual_hours))
    
    @property
    def efficiency_ratio(self):
        if self.actual_hours == 0:
            return 0
        return float(self.estimated_hours / self.actual_hours)
    
    def clean(self):
        if self.due_date and self.due_date < timezone.now().date():
            raise ValidationError("Due date cannot be in the past")
        
        if self.status == 'completed' and self.progress != 100:
            self.progress = 100
        
        if self.status == 'not_started' and self.progress > 0:
            self.status = 'in_progress'
    
    def save(self, *args, **kwargs):
        # Auto-update status based on progress
        if self.progress == 100 and self.status != 'completed':
            self.status = 'completed'
        elif self.progress == 0 and self.status == 'completed':
            self.status = 'not_started'
        
        super().save(*args, **kwargs)

class Sprint(models.Model):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='sprints')
    name = models.CharField(max_length=100)
    start_date = models.DateField()
    end_date = models.DateField()
    goals = models.TextField()
    status = models.CharField(max_length=20, choices=[
        ('planned', 'Planned'),
        ('active', 'Active'),
        ('completed', 'Completed')
    ])
    velocity = models.DecimalField(max_digits=6, decimal_places=2, default=0)
    retrospective = models.TextField(blank=True)