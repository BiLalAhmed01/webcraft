from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.views.generic import CreateView, DetailView, UpdateView, DeleteView
from django.urls import reverse_lazy
from django.contrib import messages
from django.http import JsonResponse
from django.views.decorators.csrf import ensure_csrf_cookie
from django.utils.decorators import method_decorator
from core.models import Project, ProjectMilestone, RequiredSkill, TeamMember
from core.forms import ProjectForm
from core.services.ai_service import AIService
import json
import logging
from django.views.decorators.http import require_POST
from django.shortcuts import get_object_or_404, redirect
from django.contrib import messages
from django.contrib.auth.models import User
from django.core.serializers.json import DjangoJSONEncoder
from rest_framework.views import APIView
from rest_framework.response import Response

logger = logging.getLogger(__name__)

@method_decorator(ensure_csrf_cookie, name='dispatch')
class ProjectCreateView(LoginRequiredMixin, CreateView):
    model = Project
    form_class = ProjectForm
    template_name = 'core/project_form.html'
    success_url = reverse_lazy('core:dashboard')
    
    def form_valid(self, form):
        try:
            # Set the created_by field to current user
            form.instance.created_by = self.request.user
            
            # Save the project
            project = form.save()
            
            # Get additional form data
            form_data = self.request.POST.get('formData', '{}')
            data = json.loads(form_data)
            
            # Add skills
            skills = data.get('skills', [])
            for skill in skills:
                if skill:  # Validate skill data
                    RequiredSkill.objects.create(
                        project=project,
                        name=skill.strip()
                    )
            
            # Add milestones
            milestones = data.get('milestones', [])
            for milestone in milestones:
                if milestone.get('title') and milestone.get('date'):
                    ProjectMilestone.objects.create(
                        project=project,
                        title=milestone['title'].strip(),
                        due_date=milestone['date']
                    )
            
            # Add creator as first team member with manager role
            TeamMember.objects.create(
                project=project,
                user=self.request.user,
                role='manager'
            )

            # Get AI insights for the project
            try:
                ai_service = AIService()
                project_data = {
                    'name': project.name,
                    'description': project.description,
                    'requirements': project.requirements,
                    'budget': float(project.budget),
                    'team_size': int(project.team_size),
                    'deadline': project.deadline.strftime('%Y-%m-%d'),
                    'skills': [skill.name for skill in project.required_skills.all()],
                    'milestones': [
                        {
                            'title': m.title,
                            'date': m.due_date.strftime('%Y-%m-%d')
                        }
                        for m in project.milestones.all()
                    ]
                }
                
                analysis = ai_service.analyze_project(project_data)
                if analysis:
                    logger.info(f"AI Analysis received: {analysis}")
                    project.ai_analysis = analysis
                    project.save()
            except Exception as e:
                print(f"AI analysis error: {str(e)}")
                # Don't fail project creation if AI analysis fails
                pass
            
            if self.request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({
                    'success': True,
                    'redirect_url': self.success_url,
                    'message': 'Project created successfully!'
                })
            
            messages.success(self.request, 'Project created successfully!')
            return super().form_valid(form)
            
        except Exception as e:
            # Log the error for debugging
            print(f"Error creating project: {str(e)}")
            # Delete the project if it was created but additional data failed
            if 'project' in locals():
                project.delete()
            
            if self.request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({
                    'success': False,
                    'errors': {'__all__': str(e)}
                }, status=400)
            
            messages.error(self.request, f'Error creating project: {str(e)}')
            return self.form_invalid(form)
    
    def form_invalid(self, form):
        if self.request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            errors = {}
            for field, error_list in form.errors.items():
                errors[field] = error_list[0]
            return JsonResponse({
                'success': False,
                'errors': errors
            }, status=400)
        
        messages.error(self.request, 'Please correct the errors below.')
        return super().form_invalid(form)
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['title'] = 'Create New Project'
        return context

class ProjectUpdateView(LoginRequiredMixin, UserPassesTestMixin, UpdateView):
    model = Project
    form_class = ProjectForm
    template_name = 'core/project_form.html'
    success_url = reverse_lazy('core:dashboard')
    
    def test_func(self):
        project = self.get_object()
        return self.request.user == project.created_by
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        project = self.get_object()
        context['title'] = f'Edit Project: {project.name}'
        context['is_update'] = True
        
        # Get existing skills and milestones
        context['initial_skills'] = list(project.required_skills.values_list('name', flat=True))
        context['initial_milestones'] = [
            {'title': m.title, 'date': m.due_date.strftime('%Y-%m-%d')}
            for m in project.milestones.all()
        ]
        return context
    
    def form_valid(self, form):
        try:
            project = form.save()
            
            # Get additional form data
            form_data = self.request.POST.get('formData', '{}')
            data = json.loads(form_data)
            
            # Update skills
            project.required_skills.all().delete()  # Remove existing skills
            skills = data.get('skills', [])
            for skill in skills:
                if skill:
                    RequiredSkill.objects.create(
                        project=project,
                        name=skill.strip()
                    )
            
            # Update milestones
            project.milestones.all().delete()  # Remove existing milestones
            milestones = data.get('milestones', [])
            for milestone in milestones:
                if milestone.get('title') and milestone.get('date'):
                    ProjectMilestone.objects.create(
                        project=project,
                        title=milestone['title'].strip(),
                        due_date=milestone['date']
                    )
            
            # Update AI analysis
            try:
                ai_service = AIService()
                project_data = {
                    'name': project.name,
                    'description': project.description,
                    'requirements': project.requirements,
                    'budget': float(project.budget),
                    'team_size': int(project.team_size),
                    'deadline': project.deadline.strftime('%Y-%m-%d'),
                    'skills': [skill.name for skill in project.required_skills.all()],
                    'milestones': [
                        {
                            'title': m.title,
                            'date': m.due_date.strftime('%Y-%m-%d')
                        }
                        for m in project.milestones.all()
                    ]
                }
                
                analysis = ai_service.analyze_project(project_data)
                if analysis:
                    project.ai_analysis = analysis
                    project.save()
            except Exception as e:
                print(f"AI analysis error: {str(e)}")
                pass
            
            if self.request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({
                    'success': True,
                    'redirect_url': self.success_url,
                    'message': 'Project updated successfully!'
                })
            
            messages.success(self.request, 'Project updated successfully!')
            return super().form_valid(form)
            
        except Exception as e:
            if self.request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({
                    'success': False,
                    'errors': {'__all__': str(e)}
                }, status=400)
            
            messages.error(self.request, f'Error updating project: {str(e)}')
            return self.form_invalid(form)

class ProjectDeleteView(LoginRequiredMixin, UserPassesTestMixin, DeleteView):
    model = Project
    success_url = reverse_lazy('core:dashboard')
    template_name = 'core/project_confirm_delete.html'
    
    def test_func(self):
        project = self.get_object()
        return self.request.user == project.created_by
    
    def delete(self, request, *args, **kwargs):
        try:
            project = self.get_object()
            project.delete()
            messages.success(request, 'Project deleted successfully!')
            return JsonResponse({'success': True, 'redirect_url': self.success_url})
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)}, status=400)

class ProjectDetailView(LoginRequiredMixin, DetailView):
    model = Project
    template_name = 'core/project_detail.html'
    context_object_name = 'project'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        tasks = self.object.tasks.all().select_related('assigned_to')
        
        # Prepare tasks data for Gantt chart
        tasks_data = []
        for task in tasks:
            task_data = {
                'id': str(task.id),
                'name': task.title,
                'start': task.created_at.strftime('%Y-%m-%d'),
                'end': task.due_date.strftime('%Y-%m-%d'),
                'progress': task.progress,
                'status': task.status,
                'custom_class': f'status-{task.status}',
                'dependencies': '',
                'project': task.project.name,
                'milestone': task.is_milestone if hasattr(task, 'is_milestone') else False,
                'assignee': task.assigned_to.get_full_name() if task.assigned_to else 'Unassigned'
            }
            tasks_data.append(task_data)
        
        context['tasks_json'] = json.dumps(tasks_data, cls=DjangoJSONEncoder)
        context['tasks'] = tasks
        return context

class ProjectAnalyzeView(APIView):
    def post(self, request, pk):
        try:
            # Get the project instance
            project = get_object_or_404(Project, pk=pk)
            
            # Initialize AI service
            ai_service = AIService()
            
            # Analyze project
            analysis = ai_service.analyze_project(project)  # Pass the project instance directly
            
            # Update project with analysis results
            project.update_ai_analysis(analysis)
            
            return Response({
                'success': True,
                'analysis': analysis
            })
        except Exception as e:
            logger.error(f"Error in project analysis: {str(e)}", exc_info=True)
            return Response({
                'success': False,
                'error': str(e)
            })

@require_POST
def add_team_member(request, pk):
    """Add a team member to the project."""
    project = get_object_or_404(Project, pk=pk)
    
    # Add logging for debugging
    print(f"Adding team member to project {pk}")
    print(f"Request user: {request.user}")
    print(f"Project creator: {project.created_by}")
    
    # Check if user has permission to add team members
    if request.user != project.created_by:
        messages.error(request, 'You do not have permission to add team members.')
        return redirect('core:project_detail', pk=pk)
    
    user_id = request.POST.get('user')
    role = request.POST.get('role')
    
    print(f"User ID: {user_id}, Role: {role}")
    
    if not user_id or not role:
        messages.error(request, 'Both user and role are required')
        return redirect('core:project_detail', pk=pk)
    
    try:
        user = User.objects.get(id=user_id)
        print(f"Found user: {user.username}")
        
        # Check if user is already a team member
        if project.team_members.filter(user=user).exists():
            messages.error(request, f'{user.get_full_name()} is already a team member')
            return redirect('core:project_detail', pk=pk)
            
        team_member = TeamMember.objects.create(
            project=project,
            user=user,
            role=role
        )
        print(f"Created team member: {team_member}")
        
        messages.success(
            request, 
            f'{user.get_full_name() or user.username} has been added as {dict(TeamMember.ROLE_CHOICES)[role]}'
        )
        
    except Exception as e:
        print(f"Error adding team member: {str(e)}")
        messages.error(request, f'Error adding team member: {str(e)}')
    
    return redirect('core:project_detail', pk=pk)

def debug_team_members(request, pk):
    project = get_object_or_404(Project, pk=pk)
    team_members = project.team_members.all().select_related('user')
    
    print(f"\nDebugging Team Members for Project {pk}:")
    print(f"Current User: {request.user.username}")
    print(f"Project Creator: {project.created_by.username}")
    print("Team Members:")
    for member in team_members:
        print(f"- {member.user.username} ({member.role})")
    
    data = {
        'project_id': pk,
        'team_members': [
            {
                'id': tm.id,
                'user_id': tm.user.id,
                'username': tm.user.username,
                'role': tm.role,
                'full_name': tm.user.get_full_name()
            }
            for tm in team_members
        ],
        'current_user': {
            'id': request.user.id,
            'username': request.user.username
        }
    }
    return JsonResponse(data)

@require_POST
def remove_team_member(request, pk, member_id):
    """Remove a team member from the project."""
    project = get_object_or_404(Project, pk=pk)
    
    # Check if user has permission to remove team members
    if request.user != project.created_by:
        return JsonResponse({
            'success': False, 
            'error': 'You do not have permission to remove team members.'
        }, status=403)
    
    try:
        member = TeamMember.objects.get(id=member_id, project=project)
        
        # Don't allow removing the project creator/manager
        if member.user == project.created_by:
            return JsonResponse({
                'success': False,
                'error': 'Cannot remove the project creator.'
            }, status=400)
            
        member.delete()
        return JsonResponse({'success': True})
        
    except TeamMember.DoesNotExist:
        return JsonResponse({
            'success': False,
            'error': 'Team member not found.'
        }, status=404)