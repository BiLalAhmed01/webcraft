from django.views.generic import TemplateView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.db.models import Q
from core.models import Project

class DashboardView(LoginRequiredMixin, TemplateView):
    template_name = 'core/dashboard.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Get both created projects and projects where user is a team member
        user_projects = Project.objects.filter(
            Q(created_by=self.request.user) |  # Projects created by user
            Q(team_members__user=self.request.user)  # Projects where user is a team member
        ).distinct()
        
        context.update({
            'projects': user_projects,
            'total_projects': user_projects.count(),
            'in_progress': user_projects.filter(status='in_progress').count(),
            'completed': user_projects.filter(status='completed').count(),
        })
        
        print(f"User: {self.request.user.username}")
        print(f"Projects found: {user_projects.count()}")
        print("Projects:", [f"{p.name} (Team: {list(p.team_members.all().values_list('user__username', flat=True))})" for p in user_projects])
        
        return context