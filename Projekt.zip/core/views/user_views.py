from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import UpdateView
from django.contrib.auth.models import User
from django.urls import reverse_lazy
from django.contrib import messages

class ProfileView(LoginRequiredMixin, UpdateView):
    model = User
    template_name = 'core/user/profile.html'
    fields = ['first_name', 'last_name', 'email']
    success_url = reverse_lazy('core:dashboard')

    def get_object(self, queryset=None):
        return self.request.user

    def form_valid(self, form):
        messages.success(self.request, 'Profile updated successfully!')
        return super().form_valid(form) 