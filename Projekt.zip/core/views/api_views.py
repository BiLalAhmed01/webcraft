from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import get_object_or_404
from core.models import Project
from core.services.ai_service import AIService
import logging

logger = logging.getLogger(__name__)

class ProjectAnalyzeView(APIView):
    def get_project_data(self, project):
        """Prepare project data for AI analysis"""
        return {
            "name": project.name,
            "description": project.description,
            "tasks": list(project.tasks.all().values('title', 'description', 'status')),
            "team_members": list(project.team_members.all().values('user__username', 'role')),
            "milestones": list(project.milestones.all().values('title', 'due_date')),
        }

    def post(self, request, pk):
        try:
            project = get_object_or_404(Project, pk=pk)
            ai_service = AIService()
            
            # Get project data
            project_data = self.get_project_data(project)
            
            # Get AI analysis
            analysis = ai_service.analyze_project(project_data)
            
            if 'error' in analysis:
                return Response({
                    'success': False,
                    'error': analysis['error']
                }, status=400)
            
            # Save the analysis to the project
            project.ai_analysis = analysis
            project.save()
            
            return Response({
                'success': True,
                'analysis': analysis
            })
            
        except Exception as e:
            logger.error(f"Error in AI analysis: {str(e)}")
            return Response({
                'success': False,
                'error': str(e)
            }, status=500)