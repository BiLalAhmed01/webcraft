from .auth_views import LoginView, LogoutView, RegisterView
from .project_views import ProjectCreateView, ProjectDetailView, ProjectUpdateView, ProjectDeleteView
from .dashboard_views import DashboardView
from .api_views import ProjectAnalyzeView
from .task_views import TaskListView, TaskCreateView, TaskUpdateView, TaskDeleteView
from .user_views import *

__all__ = [
    'LoginView', 'LogoutView', 'RegisterView',
    'ProjectCreateView', 'ProjectDetailView', 'ProjectUpdateView', 'ProjectDeleteView',
    'DashboardView',
    'ProjectAnalyzeView',
    'TaskListView', 'TaskCreateView', 'TaskUpdateView', 'TaskDeleteView'
] 