from django.views.generic import ListView, CreateView, UpdateView, DeleteView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.urls import reverse_lazy
from django.shortcuts import get_object_or_404
from django.contrib import messages
from django.http import JsonResponse
from core.models import Task, Project, User
from core.services.ai_service import AIService
from core.forms import TaskForm
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
import logging

logger = logging.getLogger(__name__)

class TaskListView(LoginRequiredMixin, ListView):
    model = Task
    template_name = 'core/tasks/task_list.html'
    context_object_name = 'tasks'
    
    def get_queryset(self):
        self.project = get_object_or_404(Project, id=self.kwargs['project_id'])
        return Task.objects.filter(project=self.project).select_related('assigned_to')
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context.update({
            'project': self.project,
            'task_statuses': Task.STATUS_CHOICES,
            'task_priorities': Task.PRIORITY_CHOICES,
            'team_members': self.project.team_members.all(),
        })
        return context

class TaskCreateView(LoginRequiredMixin, CreateView):
    model = Task
    template_name = 'core/tasks/task_form.html'
    fields = ['title', 'description', 'assigned_to', 'status', 'priority', 'due_date']

    def get_form(self, form_class=None):
        form = super().get_form(form_class)
        project = get_object_or_404(Project, pk=self.kwargs['project_id'])
        # Get users who are team members of the project using team_memberships
        team_member_users = User.objects.filter(team_memberships__project=project)
        form.fields['assigned_to'].queryset = team_member_users
        return form

    def form_valid(self, form):
        project = get_object_or_404(Project, pk=self.kwargs['project_id'])
        form.instance.project = project
        return super().form_valid(form)
    
    def get_success_url(self):
        return reverse_lazy('core:task_list', kwargs={'project_id': self.kwargs['project_id']})

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['project'] = get_object_or_404(Project, pk=self.kwargs['project_id'])
        return context

class TaskUpdateView(LoginRequiredMixin, UpdateView):
    model = Task
    form_class = TaskForm
    template_name = 'core/tasks/task_form.html'
    
    def get_project(self):
        return get_object_or_404(Project, id=self.kwargs['project_id'])
    
    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs['project'] = self.get_project()
        return kwargs
    
    def form_valid(self, form):
        response = super().form_valid(form)
        messages.success(self.request, 'Task updated successfully')
        return response
    
    def get_success_url(self):
        return reverse_lazy('core:task_list', kwargs={'project_id': self.kwargs['project_id']})
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['project'] = self.get_project()
        return context

class TaskDeleteView(APIView):
    def delete(self, request, pk):
        try:
            task = get_object_or_404(Task, pk=pk)
            
            # Check permissions
            if request.user != task.project.created_by and not task.project.team_members.filter(user=request.user).exists():
                return Response({"error": "Not authorized"}, status=status.HTTP_403_FORBIDDEN)
            
            task.delete()
            return Response(status=status.HTTP_204_NO_CONTENT)
            
        except Exception as e:
            logger.error(f"Error deleting task: {str(e)}")
            return Response(
                {"error": f"Error deleting task: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

class TaskReassignView(APIView):
    def post(self, request, pk):
        try:
            task = get_object_or_404(Task, pk=pk)
            user_id = request.data.get('user_id')
            
            # Check permissions
            if request.user != task.project.created_by and not task.project.team_members.filter(user=request.user).exists():
                return Response({"error": "Not authorized"}, status=status.HTTP_403_FORBIDDEN)
            
            # Update task assignment
            task.assigned_to_id = user_id
            task.save()
            
            return Response({"message": "Task reassigned successfully"})
            
        except Exception as e:
            logger.error(f"Error reassigning task: {str(e)}")
            return Response(
                {"error": f"Error reassigning task: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )