from rest_framework import permissions
from .models import ProjectMember

class IsProjectMember(permissions.BasePermission):
    def has_object_permission(self, request, view, obj):
        # Get the project from the object
        if hasattr(obj, 'project'):
            project = obj.project
        elif hasattr(obj, 'task'):
            project = obj.task.project
        else:
            project = obj

        # Check if user is a member of the project
        return project.team_members.filter(id=request.user.id).exists()

class IsProjectAdmin(permissions.BasePermission):
    def has_object_permission(self, request, view, obj):
        # Get the project from the object
        if hasattr(obj, 'project'):
            project = obj.project
        elif hasattr(obj, 'task'):
            project = obj.task.project
        else:
            project = obj

        # Check if user is an admin of the project
        return ProjectMember.objects.filter(
            user=request.user,
            project=project,
            role=ProjectMember.Role.ADMIN
        ).exists()

class IsProjectManager(permissions.BasePermission):
    def has_object_permission(self, request, view, obj):
        # Get the project from the object
        if hasattr(obj, 'project'):
            project = obj.project
        elif hasattr(obj, 'task'):
            project = obj.task.project
        else:
            project = obj

        # Check if user is a project manager
        return ProjectMember.objects.filter(
            user=request.user,
            project=project,
            role__in=[ProjectMember.Role.ADMIN, ProjectMember.Role.PROJECT_MANAGER]
        ).exists()

class IsOwnerOrReadOnly(permissions.BasePermission):
    def has_object_permission(self, request, view, obj):
        # Read permissions are allowed to any request,
        # so we'll always allow GET, HEAD or OPTIONS requests.
        if request.method in permissions.SAFE_METHODS:
            return True

        # Check if the user is the owner of the object
        owner_field = getattr(obj, 'owner', None) or \
                     getattr(obj, 'created_by', None) or \
                     getattr(obj, 'author', None) or \
                     getattr(obj, 'uploaded_by', None)
        
        return owner_field == request.user 