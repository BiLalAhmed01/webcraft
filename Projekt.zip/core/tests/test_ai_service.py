import pytest
from core.services.ai_service import AIService
from unittest.mock import patch, MagicMock

@pytest.mark.asyncio
class TestAIService:
    @pytest.fixture
    def ai_service(self):
        return AIService()

    @pytest.fixture
    def sample_project_data(self):
        return {
            "name": "E-commerce Platform",
            "requirements": "Build a modern e-commerce platform with payment integration, inventory management, and user authentication",
            "budget": 50000,
            "team_size": 5,
            "deadline": "2024-06-01"
        }

    async def test_analyze_project(self, ai_service, sample_project_data):
        # Test project analysis
        analysis = await ai_service.analyze_project(sample_project_data)
        
        # Verify the structure of the response
        assert isinstance(analysis, dict)
        assert "risk_assessment" in analysis
        assert "resource_allocation" in analysis
        assert "timeline_optimization" in analysis
        assert "recommendations" in analysis

    async def test_suggest_milestones(self, ai_service, sample_project_data):
        # Test milestone suggestions
        milestones = await ai_service.suggest_milestones(sample_project_data)
        
        # Verify the structure of the response
        assert isinstance(milestones, list)
        if milestones:  # If any milestones are returned
            assert all(isinstance(m, dict) for m in milestones)
            assert all("title" in m for m in milestones)
            assert all("duration" in m for m in milestones)
            assert all("description" in m for m in milestones)

    async def test_recommend_team_composition(self, ai_service, sample_project_data):
        # Test team composition recommendations
        recommendations = await ai_service.recommend_team_composition(sample_project_data)
        
        # Verify the structure of the response
        assert isinstance(recommendations, list)
        if recommendations:  # If any recommendations are returned
            assert all(isinstance(r, dict) for r in recommendations)
            assert all("role" in r for r in recommendations)
            assert all("skills" in r for r in recommendations)
            assert all("responsibilities" in r for r in recommendations)

    async def test_generate_project_update(self, ai_service, sample_project_data):
        progress_data = {
            "completion_percentage": 35,
            "timeline_status": "on track",
            "budget_status": "within budget",
            "challenges": ["Integration delays", "Resource constraints"]
        }
        
        # Test project update generation
        update = await ai_service.generate_project_update(sample_project_data, progress_data)
        
        # Verify the structure of the response
        assert isinstance(update, dict)
        assert "status_summary" in update
        assert "key_achievements" in update
        assert "challenges" in update
        assert "recommendations" in update

    async def test_error_handling(self, ai_service):
        # Test with invalid data
        invalid_data = {}
        
        # Test error handling in analyze_project
        analysis = await ai_service.analyze_project(invalid_data)
        assert "error" in analysis
        
        # Test error handling in suggest_milestones
        milestones = await ai_service.suggest_milestones(invalid_data)
        assert isinstance(milestones, list)
        assert len(milestones) == 0
        
        # Test error handling in recommend_team_composition
        recommendations = await ai_service.recommend_team_composition(invalid_data)
        assert isinstance(recommendations, list)
        assert len(recommendations) == 0

    @patch('google.generativeai.GenerativeModel')
    async def test_api_error_handling(self, mock_model, ai_service, sample_project_data):
        # Mock API error
        mock_instance = MagicMock()
        mock_instance.generate_content.side_effect = Exception("API Error")
        mock_model.return_value = mock_instance
        
        # Test error handling
        analysis = await ai_service.analyze_project(sample_project_data)
        assert "error" in analysis
        assert "Failed to analyze project" in analysis["error"] 