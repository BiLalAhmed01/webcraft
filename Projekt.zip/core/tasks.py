from celery import shared_task
from django.core.mail import send_mail
from django.conf import settings
from .models import Project, Task
from .services.ai_service import AIService

@shared_task
def generate_project_recommendations(project_id):
    """Generate AI recommendations for a project."""
    try:
        project = Project.objects.get(id=project_id)
        ai_service = AIService()

        # Generate various recommendations
        ai_service.optimize_resource_allocation(project)
        ai_service.assess_project_risks(project)
        ai_service.generate_performance_insights(project)

        # Notify project owner
        send_mail(
            'AI Recommendations Generated',
            'New AI recommendations have been generated for your project.',
            settings.DEFAULT_FROM_EMAIL,
            [project.owner.email],
            fail_silently=True,
        )

    except Project.DoesNotExist:
        pass

@shared_task
def notify_task_assignment(task_id):
    """Notify user about task assignment."""
    try:
        task = Task.objects.get(id=task_id)
        if task.assignee and task.assignee.email:
            send_mail(
                'New Task Assignment',
                f'You have been assigned to the task: {task.title}',
                settings.DEFAULT_FROM_EMAIL,
                [task.assignee.email],
                fail_silently=True,
            )
    except Task.DoesNotExist:
        pass

@shared_task
def notify_task_due_soon():
    """Notify users about tasks due soon."""
    from datetime import datetime, timedelta
    
    # Get tasks due in the next 24 hours
    due_soon = datetime.now() + timedelta(days=1)
    tasks = Task.objects.filter(
        due_date__lte=due_soon,
        status__in=['NOT_STARTED', 'IN_PROGRESS']
    ).select_related('assignee')

    for task in tasks:
        if task.assignee and task.assignee.email:
            send_mail(
                'Task Due Soon',
                f'Task "{task.title}" is due in 24 hours.',
                settings.DEFAULT_FROM_EMAIL,
                [task.assignee.email],
                fail_silently=True,
            )

@shared_task
def update_project_metrics(project_id):
    """Update project metrics and generate insights."""
    try:
        project = Project.objects.get(id=project_id)
        ai_service = AIService()
        
        # Generate performance insights
        ai_service.generate_performance_insights(project)

        # Notify project owner
        send_mail(
            'Project Metrics Updated',
            'Project metrics have been updated and new insights are available.',
            settings.DEFAULT_FROM_EMAIL,
            [project.owner.email],
            fail_silently=True,
        )

    except Project.DoesNotExist:
        pass 