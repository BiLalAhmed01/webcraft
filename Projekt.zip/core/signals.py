from django.db.models.signals import post_save, post_delete
from django.dispatch import receiver
from .models import Project, Task, ProjectMember
from .tasks import generate_project_recommendations, notify_task_assignment, update_project_metrics

@receiver(post_save, sender=Project)
def project_post_save(sender, instance, created, **kwargs):
    """Handle project creation and updates."""
    if created:
        # Generate initial AI recommendations
        generate_project_recommendations.delay(instance.id)
    else:
        # Update project metrics
        update_project_metrics.delay(instance.id)

@receiver(post_save, sender=Task)
def task_post_save(sender, instance, created, **kwargs):
    """Handle task creation and updates."""
    if created:
        # Notify assigned user
        if instance.assignee:
            notify_task_assignment.delay(instance.id)
    
    # Update project metrics when task status changes
    if not created and instance.tracker.has_changed('status'):
        update_project_metrics.delay(instance.project.id)

@receiver(post_save, sender=ProjectMember)
def project_member_post_save(sender, instance, created, **kwargs):
    """Handle project member addition."""
    if created:
        # Update resource allocation recommendations
        generate_project_recommendations.delay(instance.project.id)

@receiver(post_delete, sender=ProjectMember)
def project_member_post_delete(sender, instance, **kwargs):
    """Handle project member removal."""
    # Update resource allocation recommendations
    generate_project_recommendations.delay(instance.project.id) 