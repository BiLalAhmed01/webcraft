from dotenv import load_dotenv
import os

load_dotenv()

# Add this to your settings
GEMINI_API_KEY = os.getenv('GEMINI_API_KEY') 