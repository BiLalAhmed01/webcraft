from django.core.management.base import BaseCommand
from django.contrib.auth.models import User

class Command(BaseCommand):
    help = 'Creates test users for development'

    def handle(self, *args, **kwargs):
        test_users = [
            {
                'username': 'frontend_dev',
                'password': 'testpass123',
                'first_name': 'John',
                'last_name': 'Developer',
                'email': 'frontend@test.com'
            },
            {
                'username': 'ui_designer',
                'password': 'testpass123',
                'first_name': 'Sarah',
                'last_name': 'Designer',
                'email': 'designer@test.com'
            },
            {
                'username': 'backend_dev',
                'password': 'testpass123',
                'first_name': 'Mike',
                'last_name': 'Backend',
                'email': 'backend@test.com'
            }
        ]

        for user_data in test_users:
            if not User.objects.filter(username=user_data['username']).exists():
                User.objects.create_user(**user_data)
                self.stdout.write(
                    self.style.SUCCESS(f'Successfully created user {user_data["username"]}')
                )
            else:
                self.stdout.write(
                    self.style.WARNING(f'User {user_data["username"]} already exists')
                ) 