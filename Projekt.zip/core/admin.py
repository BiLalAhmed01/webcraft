from django.contrib import admin
from .models import Project, ProjectMilestone, RequiredSkill, ProjectUpdate

@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = ('name', 'created_by', 'status', 'deadline', 'progress')
    list_filter = ('status', 'created_at')
    search_fields = ('name', 'description', 'requirements')
    date_hierarchy = 'created_at'

@admin.register(ProjectMilestone)
class ProjectMilestoneAdmin(admin.ModelAdmin):
    list_display = ('title', 'project', 'due_date', 'status')
    list_filter = ('status', 'due_date')
    search_fields = ('title', 'description', 'project__name')
    date_hierarchy = 'due_date'

@admin.register(RequiredSkill)
class RequiredSkillAdmin(admin.ModelAdmin):
    list_display = ('name', 'project')
    list_filter = ('project',)
    search_fields = ('name', 'project__name')

@admin.register(ProjectUpdate)
class ProjectUpdateAdmin(admin.ModelAdmin):
    list_display = ('project', 'author', 'created_at')
    list_filter = ('created_at', 'author')
    search_fields = ('content', 'project__name', 'author__username')
    date_hierarchy = 'created_at' 